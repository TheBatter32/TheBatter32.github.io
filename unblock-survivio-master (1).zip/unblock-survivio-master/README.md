# unblock-survivio
## This repository is archived.
I'm not even sure if this works anymore. It's been many years since I've used it. Somehow, for some reason, people still seem to be using it, which is great, but I am no longer going to work on it. So, this repository will be archived. You can still use it and modify it, as long as you fork it.

This is a GitHub repo that uses an iframe to bypass a Chrome extension that blocks games and other cool stuff. My fellow students are particulary fond of Surviv.io, but the extension blocked the websites for it. Some websites worked, but fullscreen didn't work.
<br>
The solution? Make something that can bypass it.
<br>

*So I did.*

Want to add a website to this list? Make a GitHub Issue with the URL and website name! Or fork it.

# *This may not work if your school has a filter or firewall that blocks games. (aka IP blocking)*

## This will not work with devices that use the Securly VPN, such as iPads and iPhones.
This will, however, work with the Chrome extension. It’s made for the extension and tested on the extension, so if your device doesn’t have it, it may not work. It's optimized for Chromebooks, since that's what I tested it on. It should work with all other devices with the extension though.
## This may not work if your school has a filter or firewall that blocks games. (aka IP blocking)


## Things that are Not Games But Still Pretty Cool I Guess
### [Click Here to Access Bing](https://randomblock1.github.io/unblock-survivio/bing.html "Note: you can’t click links")

## Games
### [Click Here to Access Surviv.io](https://randomblock1.github.io/unblock-survivio/survivio.html "Surviv.io Unblocked!")
### [Click Here to Access Agar.io](https://randomblock1.github.io/unblock-survivio/agar.html "Agar.io Unblocked!")
### [Click Here to Access Shell Shockers](https://randomblock1.github.io/unblock-survivio/shellshockers.html "Shell Shockers Unblocked!")
### [Click Here to Access Bonk.io](https://randomblock1.github.io/unblock-survivio/bonk.html "Bonk.io Unblocked!")
### [Click Here to Access OurWorld](https://randomblock1.github.io/unblock-survivio/ourworld.html "OurWorld Unblocked!")
### [Click Here to Access Diep.io](https://randomblock1.github.io/unblock-survivio/diep.html "Diep.io Unblocked!")
### [Click Here to Access CoolMathGames!](https://randomblock1.github.io/unblock-survivio/coolmathgames.html "ah, the good old days")
<br><br><br><br><br><br><br><br>

Powered by [Randomblock1’s GitHub repo](https://github.com/Randomblock1/unblock-survivio "GitHub: where all the cool kids hang out") and made with ❤️
