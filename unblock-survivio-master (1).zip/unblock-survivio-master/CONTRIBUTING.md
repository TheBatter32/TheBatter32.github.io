If you want to contribute to unblock-survivio, please read [thisishowyoudoit.txt](https://github.com/Randomblock1/unblock-survivio/blob/master/thisishowyoudoit.txt) first.

Then, create a fork and make a pull request by:
- Forking it
- Add new files, edit files, etc all in your newly forked code
- Make a pull request
