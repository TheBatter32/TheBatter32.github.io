---
name: Website request
about: Suggest an website for this project
title: Add a website
labels: enhancement
assignees: ''

---

**What is the website you want to add to this repo? (Include URL)**
Ex. github.com

**What does the website you are trying to add do?**
Ex. GitHub hosts code

**Did you create a fork adding the things you want and make a pull request?**
Yes/No/Working on it

**Additional context**
Add any other context or screenshots about the website here.
