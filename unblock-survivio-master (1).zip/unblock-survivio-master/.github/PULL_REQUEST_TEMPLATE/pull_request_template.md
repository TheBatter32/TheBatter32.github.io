Pull Request for Adding a Feature, Fixing a Bug, or Adding a Website
 - List what you are adding here, like 'added example.com' or 'fixed a bug'
 - Explain in more detail what you did
 - Please list anything that could be improved with your commits, like 'it sometimes doesn't work'
